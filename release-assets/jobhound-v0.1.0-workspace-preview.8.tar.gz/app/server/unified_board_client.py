"""Public-only transport to the same service as the hosted human board."""
import json
from urllib.parse import urlsplit
import httpx
from fastapi import HTTPException
from .external_http import external_client_kwargs

ENDPOINT = "https://job-hound.realperson.chatgpt.site/api/public-jobs/v2"
MAX_BYTES = 4 * 1024 * 1024

class UnifiedBoardClient:
    def __init__(self, endpoint=ENDPOINT, transport=None):
        parsed = urlsplit(endpoint)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Public search requires credential-free HTTPS")
        self.endpoint, self.transport = endpoint, transport

    def read(self, operation, **parameters):
        params = [("op", operation)]
        for key, value in parameters.items():
            if value is None or value == "" or value == []:
                continue
            for item in value if isinstance(value, list) else [value]:
                params.append((key, str(item).lower() if isinstance(item, bool) else str(item)))
        try:
            with httpx.Client(timeout=30, follow_redirects=False, **external_client_kwargs(transport=self.transport)) as client:
                with client.stream("GET", self.endpoint, params=params) as response:
                    data = bytearray()
                    for part in response.iter_bytes():
                        data.extend(part)
                        if len(data) > MAX_BYTES:
                            raise ValueError("Public search response exceeded its read budget")
                    body = json.loads(data)
                    if response.status_code != 200:
                        raise HTTPException(response.status_code if response.status_code in (400,404,410,422) else 503, body.get("error", "Public search unavailable; this is not a zero-match result."))
                    if not isinstance(body, dict):
                        raise ValueError("Invalid public search response")
                    return body
        except (httpx.HTTPError, ValueError) as exc:
            raise HTTPException(503, "Combined public search unavailable; saved roles remain local. This is not a zero-match result.") from exc

    def search(self, query):
        if query.offset:
            raise HTTPException(400, "Continue with next_cursor as query.cursor; combined search does not use offsets.")
        if query.location:
            raise HTTPException(400, "Use countries (two-letter codes) and cities for location filters.")
        result = self.read("search", q=query.query, countries=query.countries, cities=query.cities,
            company_ids=query.company_ids, collections=query.collection_ids, work_modes=query.work_modes,
            employment_types=query.employment_types, salary_listed=query.salary_listed,
            posted_within_days=query.posted_within_days, sort=query.sort, limit=query.limit, cursor=query.cursor)
        if result.get("version") != 2 or not isinstance(result.get("items"), list) or not isinstance(result.get("total_upper_bound"), int):
            raise HTTPException(503, "Unsupported combined public search response")
        return {**result, "total":result["total_upper_bound"], "total_exact":False, "offset":0, "limit":query.limit,
            "facets":{"companies":[], "collections":[], "work_modes":["remote","hybrid","onsite"], "employment_types":["full_time","part_time","contract","internship","fellowship"]}}
